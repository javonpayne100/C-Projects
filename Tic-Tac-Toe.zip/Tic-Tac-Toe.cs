﻿using System;

namespace Tic_Tac_Toe
{//Javon Payne
 //02DEC2020
 //Tic-Tac-Toe
    class Program
    {                                          //x //y
        private static char[,] board = new char[3, 3];
        private static char turn = 'X'; //use 2 dimensional array
        
        static void Main(string[] args)
        {
            char playAgain = 'y';       
            while (playAgain == 'y')
            {



                //while the player wants to keep playing
                InitArray();
                PrintBoard();

                char result = ' ';               //what can I compare in for loop?
                while (result == ' ')           //while loop nested in for loop?
                {

                    HumanTurn();
                    PrintBoard();
                    result = WhoWonGame();                       //order of turns
                    if (result != ' ')
                        break;
                    SwitchTurn(ref turn);           //Program worked once and declared human as winner
                    ComputerTurn();                 //but once tried again, human loops forever when
                                                    //appropriate selection is made.
                    PrintBoard();
                    SwitchTurn(ref turn);       //For Loop? Ask teacher.







                    result = WhoWonGame();
                }

                if (result == 'X')
                {
                    Console.WriteLine("X wins!");
                    Console.WriteLine("Would you like to play again? (Y/N)?: ");
                    playAgain = char.Parse(Console.ReadLine());
                }
                if (result == 'O')
                {
                    Console.WriteLine("O has won!");
                    Console.WriteLine("Would you like to play again? (Y/N)?: ");
                    playAgain = char.Parse(Console.ReadLine());
                }
                if (result == 'T')
                {
                    Console.WriteLine("It's a tie!");
                    Console.WriteLine("Would you like to play again? (Y/N)?: ");
                    playAgain = char.Parse(Console.ReadLine());
                }
                //Would you like to play again
            }
        }
        static void InitArray()
        {
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++) //for if game is in play still
                {
                    board[row, col] = ' ';
                }
            }
        }

        static void PrintBoard()
        {
            Console.WriteLine("-------------");
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    Console.Write($"| {board[row, col]} ");
                }
                Console.WriteLine("|");
                Console.WriteLine("-------------");
            }
        }
        static void ComputerTurn()
        {
            Random random = new Random();
            
            int rand = random.Next(0,2);                           
            int row;                                               
            int col;                                               
            Console.WriteLine("Computer's turn");
            Console.WriteLine("Input a row 0, 1, or 2");
            row = random.Next(0,3);

            Console.WriteLine("Input a column 0, 1, 2");
            col = random.Next(0,3);
            //cpu on goes once randomly
            while (row < 0 || row > 2 || col < 0 || col > 2 || !IsVacant(row, col))//humans turn
            {                                                                      //while loop for computer?
               // Console.WriteLine("that is an invalid entry. Try again.");


                //Console.WriteLine("Input a row 0, 1, or 2");
                row = random.Next(0, 3);

               // Console.WriteLine("Input a column 0, 1, 2");
                col = random.Next(0, 3);

                
            }
            board[row, col] = turn;
        }
        static void SwitchTurn(ref char turn)
        {
            if (turn == 'X')
            {
                turn = 'O';
            }
            else if (turn == 'O')
            {
                turn = 'X';
            }
        }
       
        static void HumanTurn()
        {
            Console.WriteLine("Input a row 0, 1, or 2");
            int row = int.Parse(Console.ReadLine());

            Console.WriteLine("Input a column 0, 1, 2");
            int col = int.Parse(Console.ReadLine());

            Console.WriteLine(IsVacant(row,col));
            while (row < 0 || row > 2 || col < 0 || col > 2 || !IsVacant(row, col))
            {
                Console.WriteLine(IsVacant(row, col));
                Console.WriteLine("Invalid entry. Try again.");

                Console.WriteLine("Input a row 0, 1, or 2");
                row = int.Parse(Console.ReadLine());

                Console.WriteLine("Input a column 0, 1, 2");
                col = int.Parse(Console.ReadLine());

                
                
            }
            board[row, col] = turn;
        }
            
            //Helper Method
            static bool IsVacant(int row, int col)
            {
            if (board[row, col] == ' ')
                return true;
            else
            {
                return false;
            }
            }
            /*static bool SwitchTurn(ref int col, int row)
                {
                    if (board[row, col] == 'X')

                        return true;
                    return false;




                    //if the value of turn is 'X', assign 'O' to turn
                    //if the value of turn is 'O', assign 'X' to turn
            }
            */

            static char WhoWonGame()
            {
                // T - cat's game
                // X - X won
                // O - O Won
                //' ' - Game still in play

                //Check if X or O won.  //8 winning statements or use for loop
                if (board[0, 0] == 'X' && board[1, 1] == 'X' && board[2, 2] == 'X')         //for loop      //check for typos
                {
                    return 'X';
                }
                else if (board[0, 0] == 'O' && board[1, 1] == 'O' && board[2, 2] == 'O')//solution1
                {
                    return 'O';
                }
                else if (board[0, 0] == 'X' && board[1, 0] == 'X' && board[2, 0] == 'X')
                {
                    return 'X';
                }
                else if (board[0, 0] == 'O' && board[1, 0] == 'O' && board[2, 0] == 'O') //solution2
                {
                    return 'O';
                }
                else if (board[0, 0] == 'X' && board[0, 1] == 'X' && board[0, 2] == 'X')
                {
                    return 'X';
                }
                else if (board[0, 0] == 'O' && board[0, 1] == 'O' && board[0, 2] == 'O')//solution3
                {
                    return 'O';
                }
                else if (board[1, 0] == 'X' && board[1, 1] == 'X' && board[1, 2] == 'X')
                {
                    return 'X';
                }
                else if (board[1, 0] == 'O' && board[1, 1] == 'O' && board[1, 2] == 'O')//solution4
                {
                    return 'O';
                }
                else if (board[2, 0] == 'X' && board[2, 1] == 'X' && board[2, 2] == 'X')
                {
                    return 'X';
                }
                else if (board[2, 0] == 'O' && board[2, 1] == 'O' && board[2, 2] == 'O')//solution5
                {
                    return 'O';
                }
                else if (board[2, 0] == 'X' && board[1, 1] == 'X' && board[0, 2] == 'X')
                {
                    return 'X';
                }
                else if (board[2, 0] == 'O' && board[1, 1] == 'O' && board[0, 2] == 'O')//solution6
                {
                    return 'O';
                }
                else if (board[0, 2] == 'X' && board[1, 2] == 'X' && board[2, 2] == 'X')
                {
                    return 'X';
                }
                else if (board[0, 2] == 'O' && board[1, 2] == 'O' && board[2, 2] == 'O')//solution7
                {
                    return 'O';
                }
                else if (board[0, 1] == 'X' && board[1, 1] == 'X' && board[1, 2] == 'X')
                {
                    return 'X';
                }
                else if (board[0, 2] == 'O' && board[1, 2] == 'O' && board[2, 2] == 'O')//solution8
                {
                    return 'O';
                }


            //Are there spaces on the board
            

                    for (int row = 0; row < 3; row++)
                    {
                        for (int col = 0; col < 3; col++)
                        {
                            if (board[row, col] == ' ')
                            {
                                return ' ';
                            }
                        }
                    }

                    //Tie Game
                    return 'T';
                }
            
        }
    }

