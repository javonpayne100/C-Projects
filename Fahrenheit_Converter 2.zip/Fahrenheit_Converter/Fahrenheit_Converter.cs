﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            double fahrenheit;
            double celsius;
            if(textBox1.Text != "")
            {
                fahrenheit = double.Parse(textBox1.Text);
                celsius = (fahrenheit - 32) * 5 / 9;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ConvertButton_Click(object sender, EventArgs e)
        {
            double fahrenheit;
            fahrenheit = double.Parse(textBox1.Text);

            double celsius;
            celsius = (fahrenheit - 32) * 5 / 9;

            label2.Text =  $"{fahrenheit} Fahrenheit is {celsius} celsius";//finish logic
           // int celsius, fahrenheit;
            if (ConvertButton.Text != "")
            {
                

               
            }
            
            double number;
            
            if (Double.TryParse(textBox1.Text, out number) && (number <= 32))
            {
                //int fahrenheit = textBox1;
                //int celsius = (5 / 9) * (fahrenheit - 32);
                
                this.BackColor = Color.Aqua;
                label1.Text = "COLD!";
            }
            else if (Double.TryParse(textBox1.Text, out number) && (number >= 85))
            {
                this.BackColor = Color.Red;
                label1.Text = "HOT!";
            }
            else if (Double.TryParse(textBox1.Text, out number) && number > 32 && number < 85)
            {
                this.BackColor = Color.Yellow;
                label1.Text = "WARM!";
            }
            else
            {
                this.BackColor = Color.Peru;
                label1.Text = "That is NOT a number!";
                label1.Focus();
                textBox1.SelectionStart = 0;
                textBox1.SelectionLength = textBox1.Text.Length;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtNumber(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
