﻿using System;

namespace AgeCalculator
{
    class Program
    {/*Javon Payne
       02SEP2020
       MyAgeCalculator
     */
        static void Main(string[] args)
        {
            string name;
            int age;
            int year;

            Console.Write("Please enter your name: ");
            name = Console.ReadLine();

            Console.Write("Please enter your birth year: ");
            year = int.Parse(Console.ReadLine());

            age = 2020 - year;

            if (age >= 18)
            {
                Console.WriteLine($"{name} is {age} years old, is an adult");
            }
            else
            {
                Console.WriteLine($"{name} is {age} years old, is a minor");
            }
        }
    }
}
